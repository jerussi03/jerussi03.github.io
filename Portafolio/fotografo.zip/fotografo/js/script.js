const images = document.querySelectorAll('.banner-img');
let currentIndex = 0;

images[currentIndex].classList.add('active');

function changeImage() {
    images[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % images.length;
    images[currentIndex].classList.add('active');
}

setInterval(changeImage, 4000); // Cambia cada 4 segundos